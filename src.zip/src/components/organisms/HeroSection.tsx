// components/organisms/HeroSection.tsx
'use client';

import React from 'react';
import HeroImage from '@/components/atoms/HeroImage';
import TypingText from '@/components/atoms/TypingText';

interface HeroSectionProps {
  name: string;
  summary: string;
  photoUrl: string;
}

export default function HeroSection({ name, summary, photoUrl }: HeroSectionProps) {
  return (
    <section className="relative flex flex-col-reverse md:flex-row items-center md:items-start gap-6 px-4 sm:px-6 lg:px-8 py-10 md:py-16">
      {/* Text block */}
      <div className="w-full md:flex-1 text-center md:text-left z-10">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-blue-500">{name}</h1>
        <div className="mt-3 text-base sm:text-lg md:text-xl text-gray-300 leading-relaxed">
          <TypingText text={summary} speed={50} />
        </div>
      </div>

      {/* Portrait */}
      <div className="w-full md:w-auto flex justify-center md:justify-end z-10">
        <div
          className="
            w-40 h-40 sm:w-48 sm:h-48 md:w-60 md:h-60
            rounded-md overflow-hidden
            border-2 sm:border-4 border-white
            shadow-lg
            filter brightness-90
            transition-transform duration-300
            hover:scale-105 hover:rotate-2
          "
        >
          <HeroImage
            src={photoUrl}
            alt={`${name} portrait`}
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </section>
  );
}
